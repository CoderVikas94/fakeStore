import { Badge } from "@material-ui/core";
import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";

const NavBar = ({ setcategory, cart }) => {
  const category = useSelector((state) => state?.loginSlice?.category);
  const handleClick = (e) => {
    setcategory(e?.target?.innerText?.toLowerCase());
  };
  const Navigate = useNavigate();
  const location = useLocation();
  console.log("location", location?.pathname == "/cart");
  return (
    <nav className="w-full h-10 flex items-center justify-end">
      <h3
        className="w-[15%] px-4 whitespace-nowrap text-black font-extrabold text-[20px]"
        onClick={() => Navigate("/")}
      >
        Fake Store
      </h3>
      <ul className="w-full list-none flex items-center justify-end">
        {location?.pathname != "/cart" && (
          <>
            {" "}
            {category?.map((item, index) => {
              return (
                <li
                  key={index}
                  onClick={handleClick}
                  className="w-[15%] px-4 whitespace-nowrap text-black font-bold text-[15px]"
                >
                  {item?.toUpperCase()}
                </li>
              );
            })}
          </>
        )}

        <li
          className="w-[15%] px-4 whitespace-nowrap text-black font-bold text-[15px]"
          onClick={() => Navigate("/cart")}
        >
          <Badge badgeContent={cart?.length} color="secondary">
            Cart
          </Badge>
        </li>
      </ul>
    </nav>
  );
};

export default NavBar;
