import * as React from "react";
import Card from "@material-ui/core/Card";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Button from "@material-ui/core/Button";
import Typography from "@material-ui/core/Typography";
import { useDispatch, useSelector } from "react-redux";
import { setCartData } from "../store/loginSlice";
import { useLocation } from "react-router-dom";

export default function Item({ item }) {
  const [addCart, setaddCart] = React.useState(false);
  const dispatch = useDispatch();
  const cart = useSelector((state) => state?.loginSlice?.cart);

  const location = useLocation();
  const handleCart = (data) => {
    setaddCart(!addCart);
    dispatch(setCartData([...cart, data]));
  };

  return (
    <Card sx={{ width: "200px" }}>
      <CardMedia
        component="img"
        alt="green iguana"
        height="50"
        width={"50"}
        image={item?.image}
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {item?.title}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {item?.description}
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small">$ {item?.price}</Button>
        <Button
          size="small"
          className={`${addCart ? "bg-red-400" : "bg-slate-500"}`}
          onClick={() => handleCart(item)}
        >
          {addCart || location?.pathname == "/cart"
            ? "Remove Cart"
            : "Add Cart"}
        </Button>
      </CardActions>
    </Card>
  );
}
