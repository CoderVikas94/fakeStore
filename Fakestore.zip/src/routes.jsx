import React from "react";
import Login from "./pages/Login";
import MainPage from "./pages/MainPage";
import Cart from "./pages/Cart";
const routes = (user) => {
  console.log("user", user);
  return [
    {
      path: "/",
      element: user != undefined ? <MainPage /> : <Login />,
      children: [
        {
          index: true,
          element: <MainPage />,
        },
      ],
    },
    { path: "/login", element: <Login /> },
    { path: "/home", element: <MainPage /> },
    {
      path: "/cart",
      element: user != undefined ? <Cart /> : <Login />,
    },
  ];
};
export default routes;
