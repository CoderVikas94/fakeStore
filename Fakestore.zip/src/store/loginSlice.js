import { createSlice } from "@reduxjs/toolkit";

const token = localStorage.getItem("token");
const myToken = JSON.parse(token || null);

const loginSlice = createSlice({
  name: "user",
  initialState: {
    user: myToken,
    product: [],
    category: [],
    cart: [],
  },
  reducers: {
    setUserData: (state, action) => {
      state.user = action.payload;
    },
    setProductData: (state, action) => {
      state.product = action.payload;
    },
    setCategorytData: (state, action) => {
      state.category = action.payload;
    },
    setCartData: (state, action) => {
      state.cart = action.payload;
      console.log("cart", state.cart);
    },
  },
});

export const { setUserData, setProductData, setCategorytData, setCartData } =
  loginSlice.actions;

export default loginSlice.reducer;
